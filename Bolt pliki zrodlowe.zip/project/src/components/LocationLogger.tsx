import React, { useState, useEffect } from 'react';
import { MapPin, Download, Trash2 } from 'lucide-react';
import LogEntryList from './LogEntryList';
import { LogEntry } from '../types/types';
import { useGeoLocation } from '../hooks/useGeoLocation';
import { downloadLogs } from '../utils/downloadUtils';

const LocationLogger: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const { getCurrentPosition, isLoading, error } = useGeoLocation();

  // Load logs from localStorage on component mount
  useEffect(() => {
    const savedLogs = localStorage.getItem('geoLogs');
    if (savedLogs) {
      setLogs(JSON.parse(savedLogs));
    }
  }, []);

  // Save logs to localStorage whenever logs change
  useEffect(() => {
    localStorage.setItem('geoLogs', JSON.stringify(logs));
  }, [logs]);

  const handleLogLocation = async () => {
    try {
      const position = await getCurrentPosition();
      const newLog: LogEntry = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        comment: ''
      };
      setLogs(prevLogs => [newLog, ...prevLogs]);
    } catch (error) {
      console.error('Error getting location:', error);
    }
  };

  const handleUpdateComment = (id: string, comment: string) => {
    setLogs(prevLogs => 
      prevLogs.map(log => 
        log.id === id ? { ...log, comment } : log
      )
    );
  };

  const handleDeleteLog = (id: string) => {
    setLogs(prevLogs => prevLogs.filter(log => log.id !== id));
  };

  const handleClearLogs = () => {
    if (window.confirm('Are you sure you want to delete all logs?')) {
      setLogs([]);
    }
  };

  const handleDownloadLogs = () => {
    downloadLogs(logs);
  };

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-lg">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Record Your Location</h2>
        <p className="text-gray-600 mb-6">
          Click the button below to log your current geo-location. You can add a comment to each entry.
        </p>
        <div className="flex flex-wrap gap-4">
          <button
            onClick={handleLogLocation}
            disabled={isLoading}
            className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200 disabled:bg-blue-400 disabled:cursor-not-allowed"
          >
            <MapPin className="h-5 w-5" />
            {isLoading ? 'Getting Location...' : 'Log My Location'}
          </button>
          <button
            onClick={handleDownloadLogs}
            disabled={logs.length === 0}
            className="flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200 disabled:bg-teal-400 disabled:cursor-not-allowed"
          >
            <Download className="h-5 w-5" />
            Download Logs
          </button>
          {logs.length > 0 && (
            <button
              onClick={handleClearLogs}
              className="flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200"
            >
              <Trash2 className="h-5 w-5" />
              Clear All Logs
            </button>
          )}
        </div>
        {error && (
          <div className="mt-4 p-3 bg-red-100 border border-red-200 text-red-700 rounded-md">
            Error: {error.message || 'Failed to get location. Please check your permissions.'}
          </div>
        )}
      </div>

      <LogEntryList 
        logs={logs} 
        onUpdateComment={handleUpdateComment} 
        onDeleteLog={handleDeleteLog} 
      />
    </div>
  );
};

export default LocationLogger;