export interface LogEntry {
  id: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  comment: string;
}